<?php
defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Api extends REST_Controller 
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('Stripe_lib');
    }


    public function index_get()
    {
        $data = [['mensaje' => 'Bienvenido Extraño'],['Version' => '1.0.0']];
        
        $this->response(['status' => true, 'data' => $data],200);
    }

    public function cobrar_post()
    {
        # code...
    }
}